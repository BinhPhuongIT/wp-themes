<?php
/**
  WPJM Config File
  For full documentation, please visit: https://github.com/ReduxFramework/ReduxFramework/wiki
 * */
if (!class_exists("ReduxFramework")) {
    return;
}

if (!class_exists("Redux_Framework_sample_config")) {

    class Redux_Framework_sample_config {

        public $args = array();
        public $sections = array();
        public $theme;
        public $ReduxFramework;

        public function __construct() {
            // This is needed. Bah WordPress bugs.  ;)
            if (ReduxFramework::$_is_plugin) {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);    
            } else {
                $this->initSettings();
            }
        }

        public function initSettings() {
            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }

            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }



        public function setSections() {

            ob_start();

            $ct = wp_get_theme();
            $this->theme = $ct;
            $item_name = $this->theme->get('Name');
            $tags = $this->theme->Tags;
            $screenshot = $this->theme->get_screenshot();
            $class = $screenshot ? 'has-screenshot' : '';

            $customize_title = sprintf(__('Customize &#8220;%s&#8221;', 'redux-framework-demo'), $this->theme->display('Name'));
            ?>
            <div id="current-theme" class="<?php echo esc_attr($class); ?>">
            <?php if ($screenshot) : ?>
                <?php if (current_user_can('edit_theme_options')) : ?>
                        <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr($customize_title); ?>">
                            <img src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
                        </a>
                <?php endif; ?>
                    <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
            <?php endif; ?>

                <h4>
            <?php echo $this->theme->display('Name'); ?>
                </h4>

                <div>
                    <ul class="theme-info">
                        <li><?php printf(__('By %s', 'redux-framework-demo'), $this->theme->display('Author')); ?></li>
                        <li><?php printf(__('Version %s', 'redux-framework-demo'), $this->theme->display('Version')); ?></li>
                        <li><?php echo '<strong>' . __('Tags', 'redux-framework-demo') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                    </ul>
                    <p class="theme-description"><?php echo $this->theme->display('Description'); ?></p>
                <?php
                if ($this->theme->parent()) {
                    printf(' <p class="howto">' . __('This <a href="%1$s">child theme</a> requires its parent theme, %2$s.') . '</p>', __('http://codex.wordpress.org/Child_Themes', 'redux-framework-demo'), $this->theme->parent()->display('Name'));
                }
                ?>

                </div>

            </div>

            <?php
            $item_info = ob_get_contents();

            ob_end_clean();


            // JOB MANAGER
            $this->sections[] = array(
                'icon' => 'el-icon-search-alt',
                'title' => __('All Jobs ', 'redux-framework-demo'),
                'desc' => __('<p class="description">Styling options for the listings archive view.</p>', 'redux-framework-demo'),
                'fields' => array(


                    // Background Section
                    array(
                        'id' => 'wpjm-section-archive-background',
                        'type' => 'section',
                        'title' => __('Backgrounds', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all backgrounds on the overall listings page.', 'redux-framework-demo'),
                        'indent' => true
                    ),

                    array(
                        'id' => 'wpjm-search-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs', '.job_filters .search_jobs'),
                        'title' => __('Search Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for the main search area.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-search-input-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs input', '#wpjm-job-styles .job_filters .search_jobs select', '.job_filters .search_jobs', '.job_filters .search_jobs select'),
                        'title' => __('Search Input Field Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for the input fields in the main search area.', 'redux-framework-demo'),
                    ),

                     array(
                        'id' => 'wpjm-filters-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .job_filters .job_types', '#wpjm-job-styles .job_filters .showing_jobs', '.job_filters .job_types', '.job_filters .showing_jobs'),
                        'title' => __('Filters Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for the job filter area (default: #F9F9F9).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-featured-listing-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing.job_position_featured a', '#wpjm-job-styles ul.job_listings li.no_job_listings_found.job_position_featured a', 'ul.job_listings li.job_listing.job_position_featured a', 'ul.job_listings li.no_job_listings_found.job_position_featured a'),
                        'title' => __('Featured Listing Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for featured job listings (default: #FEFEE5).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-featured-listing-hover-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing.job_position_featured a:hover', '#wpjm-job-styles ul.job_listings li.no_job_listings_found.job_position_featured a:hover', '#wpjm-job-styles ul.job_listings li.job_listing.job_position_featured a:focus', '#wpjm-job-styles ul.job_listings li.no_job_listings_found.job_position_featured a:focus', 'ul.job_listings li.job_listing.job_position_featured a:hover', 'ul.job_listings li.no_job_listings_found.job_position_featured a:hover', 'ul.job_listings li.job_listing.job_position_featured a:focus', 'ul.job_listings li.no_job_listings_found.job_position_featured a:focus'),
                        'title' => __('Featured Listing Hover Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color when hovering over a job listing (default: #FEFED8).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-normal-listing-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing a', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a', 'ul.job_listings li.job_listing a', 'ul.job_listings li.no_job_listings_found a'),
                        'title' => __('Normal Listing Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for normal job listings (default: #FFFFFF).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-normal-listing-hover-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing a:hover', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a:hover', '#wpjm-job-styles ul.job_listings li.job_listing a:focus', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a:focus', 'ul.job_listings li.job_listing a:hover', 'ul.job_listings li.no_job_listings_found a:hover', 'ul.job_listings li.job_listing a:focus', 'ul.job_listings li.no_job_listings_found a:focus'),
                        'title' => __('Normal Listing Hover Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color when hovering over a job listing (default: #FCFCFC).', 'redux-framework-demo'),
                    ),


                    // Border Section
                    array(
                        'id' => 'wpjm-section-archive-borders',
                        'type' => 'section',
                        'title' => __('Borders', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all borders on the overall listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),
 
                    array(
                        'id' => 'wpjm-search-section-border',
                        'type' => 'border',
                        'title' => __('Search Section Borders', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the main search section.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs', '.job_filters .search_jobs'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,
                    ),

                    array(
                        'id' => 'wpjm-search-section-filters-border',
                        'type' => 'border',
                        'title' => __('Search Filter Borders', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the main search filters.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .job_filters .job_types li, #wpjm-job-styles .job_filters .job_types, #wpjm-job-styles .job_filters .showing_jobs', '.job_filters .job_types li, .job_filters .job_types, .job_filters .showing_jobs'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,
                    ),

                    array(
                        'id' => 'wpjm-search-field-borders',
                        'type' => 'border',
                        'title' => __('Search Field Borders', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for all seach fields in the main search section.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs input', '#wpjm-job-styles .job_filters .search_jobs select', '.job_filters .search_jobs input', '.job_filters .search_jobs select'),
                        'all' => true,
                    ),

                    array(
                        'id' => 'wpjm-listings-top-border',
                        'type' => 'border',
                        'title' => __('All Listings Top Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the main search filters.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles div.job_listings ul.job_listings', 'div.job_listings ul.job_listings'),
                        'all'   => false,
                        'top' => true,
                        'right' => false,
                        'left'  => false,
                        'bottom' => false,
                    ),

                    array(
                        'id' => 'wpjm-featured-listing-border',
                        'type' => 'border',
                        'title' => __('Featured Listing Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the featured job listings.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing.job_position_featured', 'ul.job_listings li.job_listing.job_position_featured'),
                        'desc' => __('By default only the bottom border will be set to a width of 1px, with a color of #eee and set to solid. Settings here will affect all four sides of the job listing.', 'redux-framework-demo'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,                        
                    ),

                    array(
                        'id' => 'wpjm-normal-listing-border',
                        'type' => 'border',
                        'title' => __('Normal Listing Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the normal job listings.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing', '#wpjm-job-styles ul.job_listings li.no_job_listings_found', 'ul.job_listings li.job_listing', 'ul.job_listings li.no_job_listings_found'),
                        'desc' => __('By default only the bottom border will be set to a width of 1px, with a color of #eee and set to solid. Settings here will affect all four sides of the job listing.', 'redux-framework-demo'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,
                    ),


                    // Fonts Section
                    array(
                        'id' => 'wpjm-section-archive-fonts',
                        'type' => 'section',
                        'title' => __('Fonts', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all fonts on the overall listings page.', 'redux-framework-demo'),
                        'indent' => true
                    ),
                    array(
                        'id' => 'wpjm-search-section-font',
                        'type' => 'typography',
                        'title' => __('Search Fields', 'redux-framework-demo'),
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true,
                        'subsets'=>true,
                        'font-size'=>true,
                        'line-height'=>true,
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true,
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs input', '#wpjm-job-styles .job_filters .search_jobs select', '.job_filters .search_jobs input', '.job_filters .search_jobs select'),
                        'units' => 'px',
                        'subtitle' => __('Applies to all search input fields in the main search bar.', 'redux-framework-demo'),
                    ),
                    array(
                        'id' => 'wpjm-search-filters-font',
                        'type' => 'typography',
                        'title' => __('Search Filters', 'redux-framework-demo'),
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true,
                        'font-size'=>true,
                        'line-height'=>true,
                        'color'=>true,
                        'preview'=>true,
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .job_filters .job_types li', '#wpjm-job-styles .job_filters .job_types', '#wpjm-job-styles .job_filters .showing_jobs', '.job_filters .job_types li', '.job_filters .job_types', '.job_filters .showing_jobs'),
                        'units' => 'px', 
                        'subtitle' => __('Applies to all the search filters, e.g. Full Time, Freelance and Internship.', 'redux-framework-demo'),                        
                    ),
                    array(
                        'id' => 'wpjm-all-listings-font',
                        'type' => 'typography',
                        'title' => __('Listing Heading', 'redux-framework-demo'),
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                    
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing a div.position h3', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a div.position h3', 'ul.job_listings li.job_listing a div.position h3', 'ul.job_listings li.no_job_listings_found a div.position h3'),                       
                        'units' => 'px', 
                        'subtitle' => __('Typography option with each property can be called individually.', 'redux-framework-demo'),                       
                    ),
                    array(
                        'id' => 'wpjm-all-listings-meta-font',
                        'type' => 'typography',
                        'title' => __('Listing Meta', 'redux-framework-demo'),                        
                        'google' => true,
                        'font-backup' => true,
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                        
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing a div.location', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a div.location', '#wpjm-job-styles ul.job_listings li.job_listing a div.position .company', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a div.position .company', '#wpjm-job-styles ul.job_listings li.job_listing a .meta li.date', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a .meta li.date', 'ul.job_listings li.job_listing a div.location', '#ul.job_listings li.no_job_listings_found a div.location', 'ul.job_listings li.job_listing a div.position .company', 'ul.job_listings li.no_job_listings_found a div.position .company', 'ul.job_listings li.job_listing a .meta li.date', 'ul.job_listings li.no_job_listings_found a .meta li.date'),    
                        'units' => 'px', 
                        'subtitle' => __('Typography option with each property can be called individually.', 'redux-framework-demo'),
                    ),


                    // Padding Section
                    array(
                        'id' => 'wpjm-section-archive-padding',
                        'type' => 'section',
                        'title' => __('Padding / Margin', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used on the overall listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-search-section-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs', '.job_filters .search_jobs'), 
                        'mode' => 'padding', 
                        'units' => 'em', 
                        'display_units' => false, 
                        'title' => __('Search Section Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used for the main search section.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-search-section-input-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs input', '#wpjm-job-styles .job_filters .search_jobs select', '.job_filters .search_jobs input', '.job_filters .search_jobs select'), 
                        'mode' => 'padding', 
                        
                        'units' => 'em', 
                        
                        'display_units' => false, 
                        'title' => __('Search Section Input Fields Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used for input fields (e.g. Job Keywords) in the search section.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-listing-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles ul.job_listings li.job_listing a', '#wpjm-job-styles ul.job_listings li.no_job_listings_found a', 'ul.job_listings li.job_listing a', 'ul.job_listings li.no_job_listings_found a'), 
                        'mode' => 'padding',                        
                        'units' => 'em',                         
                        'display_units' => false, 
                        'title' => __('Listing Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used for each listing in the overall listings view.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    // Width Section
                    array(
                        'id' => 'wpjm-search-section-dimensions',
                        'type' => 'section',
                        'title' => __('Dimensions', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used on the overall job listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id'             => 'wpjm-search-section-input-width',
                        'type'           => 'dimensions',
                        'units'    => array('em','px','%'),
                        'units_extended' => 'true', 
                        'output' => array('#wpjm-job-styles .job_filters .search_jobs input', '#wpjm-job-styles .job_filters .search_jobs select', '.job_filters .search_jobs input', '.job_filters .search_jobs select'), 
                        'title'          => __( 'Width / Height', 'redux-framework-demo' ),
                        'subtitle'       => __( 'Allow your users to choose width / height of the job search input fields.', 'redux-framework-demo' ),
                        'default'        => array(
                            'width'  => 210,
                            'height' => 30,
                        ) 
                    ),
                ),
            );
            


            $this->sections[] = array(
                'icon' => 'el-icon-pencil-alt',
                'title' => __('Single Job', 'redux-framework-demo'),
                'desc' => __('<p class="description">Styling options for the single job listing view</p>', 'redux-framework-demo'),
                'fields' => array(

                    // Background Section
                    array(
                        'id' => 'wpjm-section-single-background',
                        'type' => 'section',
                        'title' => __('Backgrounds', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all backgrounds on the single job listing view.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-single-listing-company-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .single_job_listing .company', '.single_job_listing .company'),
                        'title' => __('Company Description Background'),
                        'subtitle' => __('Pick a background color for the main search area (default: #F5F5F5).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-single-listing-applybutton-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .single_job_listing .application .application_button', '.single_job_listing .application .application_button'),
                        'title' => __('Apply Button Background'),
                        'subtitle' => __('Pick a background color for application button (default: #FFFFFF).', 'redux-framework-demo'),
                    ),



                    // Border Section
                    array(
                        'id' => 'wpjm-section-single-borders',
                        'type' => 'section',
                        'title' => __('Borders', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all borders on the overall listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),


                    array(
                        'id' => 'wpjm-single-listing-company-border',
                        'type' => 'border',
                        'title' => __('Company Description Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for company description section (Default: 1px solid #EEEEEE).', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .single_job_listing .company', '.single_job_listing .company'),
                    ),

                    array(
                        'id' => 'wpjm-single-listing-applybutton-border',
                        'type' => 'border',
                        'title' => __('Apply Button Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for company description section (Default: 1px solid #EEEEEE).', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .single_job_listing .application .application_button', '.single_job_listing .application .application_button'),                        
                    ),



                    // Fonts Section
                    array(
                        'id' => 'wpjm-section-single-listing-fonts',
                        'type' => 'section',
                        'title' => __('Fonts', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all fonts on the overall listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                     array(
                        'id' => 'wpjm-single-listing-heading-font',
                        'type' => 'typography',
                        'title' => __('Single Listing Heading', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,         
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .single-job_listing h1.title', '.single-job_listing h1.title'),                         
                        'units' => 'px', 
                        'subtitle' => __('Applies to the main listing heading on the single listing view.', 'redux-framework-demo'),                        
                    ),

                    array(
                        'id' => 'wpjm-single-listing-company-heading-font',
                        'type' => 'typography',
                        'title' => __('Company Description Heading', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                       
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .single_job_listing .company .name', '.single_job_listing .company .name'),                         
                        'units' => 'px', 
                        'subtitle' => __('Applies to the company title in the company description area.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-single-listing-company-desc-font',
                        'type' => 'typography',
                        'title' => __('Company Description', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                     
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .single_job_listing .company .tagline', '.single_job_listing .company .tagline'),                         
                        'units' => 'px', 
                        'subtitle' => __('Applies to the general description / company tagline in the single listing view.', 'redux-framework-demo'),                     
                    ),

                    array(
                        'id' => 'wpjm-single-listing-applybutton-font',
                        'type' => 'typography',
                        'title' => __('Apply Button', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                       
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .single_job_listing .application .application_button', '.single_job_listing .application .application_button'),                    
                        'units' => 'px', 
                        'subtitle' => __('Applies to the application button in the single listing view.', 'redux-framework-demo'),
                    ),

                    
                    // Padding / Margin Section
                    array(
                        'id' => 'wpjm-single-listing-padding',
                        'type' => 'section',
                        'title' => __('Padding / Margin', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used during the job submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-single-listing-company-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .single_job_listing .company', '.single_job_listing .company'), 
                        'mode' => 'padding',                        
                        'units' => 'em',                         
                        'display_units' => false, 
                        'title' => __('Company Description Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used on the company description section.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),                        
                    ),
                ),
            );



            $this->sections[] = array(
                'icon' => 'el-icon-plus-sign',
                'title' => __('Submit Job', 'redux-framework-demo'),
                'desc' => __('<p class="description">Styling options for submitting a job listing.</p>', 'redux-framework-demo'),
                'fields' => array(

                    // Background Section
                    array(
                        'id' => 'wpjm-submit-listing-background',
                        'type' => 'section',
                        'title' => __('Backgrounds', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all backgrounds on buttons during the job submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-button-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .job-manager-form .button', '.job-manager-form .button'),
                        'preview' => false,
                        'title' => __('Button Background'),
                        'subtitle' => __('Pick a background color for all buttons during the job submission process (default: #428BCA).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-button-hover-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .job-manager-form .button:hover', '.job-manager-form .button:hover'),
                        'preview' => false,
                        'title' => __('Button Hover Background'),
                        'subtitle' => __('Pick a background color for all buttons during when hovered upon (default: #245682).', 'redux-framework-demo'),
                    ),

                    // Borders Section
                    array(
                        'id' => 'wpjm-submit-listing-borders',
                        'type' => 'section',
                        'title' => __('Borders', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all borders during the job submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-input-border',
                        'type' => 'border',
                        'title' => __('Input Borders', 'redux-framework-demo'),
                        'subtitle' => __('Set the border for the input / textarea elements during the job submission process (Default: 1px solid #EFEFEF).', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .job-manager-form fieldset input.input-text', '#wpjm-job-styles .job-manager-form fieldset textarea', '#wpjm-job-styles .job-manager-form fieldset select', '#wpjm-job-styles .job-manager-form fieldset .wp-editor-container', '.job-manager-form fieldset input.input-text', '.job-manager-form fieldset textarea', '.job-manager-form fieldset select', '.job-manager-form fieldset .wp-editor-container'),
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-fieldset-border',
                        'type' => 'border',
                        'title' => __('Fieldset Bottom Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border for areas between the input elements during the job submission process (Default: 1px solid #EEEEEE).', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .job-manager-form fieldset', '.job-manager-form fieldset'),
                        'all'   => false,
                        'top' => false,
                        'right' => false,
                        'left'  => false,
                        'bottom' => true,
                    ),


                    // Fonts Section
                    array(
                        'id' => 'wpjm-submit-listing-fonts',
                        'type' => 'section',
                        'title' => __('Fonts', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all fonts during the job submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-label-font',
                        'type' => 'typography',
                        'title' => __('Labels', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                                      
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .job-manager-form fieldset label', '.job-manager-form fieldset label'),                         
                        'units' => 'px', 
                        'subtitle' => __('Applies to all labels during the job submission process.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-input-font',
                        'type' => 'typography',
                        'title' => __('Input Fields', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                        
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .job-manager-form fieldset input.input-text', '#wpjm-job-styles .job-manager-form fieldset textarea', '#wpjm-job-styles .job-manager-form fieldset select', '#wpjm-job-styles .job-manager-form fieldset input[placeholder]', '.job-manager-form fieldset input.input-text', '.job-manager-form fieldset textarea', '.job-manager-form fieldset select', '.job-manager-form fieldset input[placeholder]'),    
                        'units' => 'px', 
                        'subtitle' => __('Applies to all input / textarea fields during the job submission process.', 'redux-framework-demo'),
                    ),


                    // Padding Section
                    array(
                        'id' => 'wpjm-submit-listing-padding',
                        'type' => 'section',
                        'title' => __('Padding / Margin', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used during the job submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-label-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .job-manager-form fieldset label', '.job-manager-form fieldset label'), 
                        'mode' => 'padding', 
                        'units' => 'em', 
                        'display_units' => false, 
                        'title' => __('Label Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used on all labels.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-submit-listing-input-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .job-manager-form fieldset input.input-text', '#wpjm-job-styles .job-manager-form fieldset textarea', '#wpjm-job-styles .job-manager-form fieldset select', '.job-manager-form fieldset input.input-text', '.job-manager-form fieldset textarea', '.job-manager-form fieldset select'), 
                        'mode' => 'padding', 
                        'all' => true, 
                        'units' => 'em',                         
                        'display_units' => false, 
                        'title' => __('Input Field Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used on all input / textarea fields.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    // Width Section
                    array(
                        'id' => 'wpjm-submit-listing-dimensions',
                        'type' => 'section',
                        'title' => __('Dimensions', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used on the overall job listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id'             => 'wpjm-submit-listing-input-width',
                        'type'           => 'dimensions',
                        'units'          => array('em','px','%'),
                        'units_extended' => 'true', 
                        'output'         => array('#wpjm-job-styles .job-manager-form fieldset input', '#wpjm-job-styles .job-manager-form fieldset textarea', '#wpjm-job-styles .job-manager-form fieldset select', '.job-manager-form fieldset input', '.job-manager-form fieldset textarea', '.job-manager-form fieldset select'), 
                        'title'          => __( 'Width / Height', 'redux-framework-demo' ),
                        'subtitle'       => __( 'Allow your users to choose width / height of the job search input fields.', 'redux-framework-demo' ),
                        'default'        => array(
                            'width'  => 210,
                            'height' => 30,
                        )
                    ), 
                ),
            );









            
            // RESUME MANAGER
            if (class_exists('WP_Resume_Manager')) {
                 $this->sections[] = array(
                'icon' => 'el-icon-spotify',
                'title' => __('All Resumes ', 'redux-framework-demo'),
                'desc' => __('<p class="description">Styling options for the resume listings archive view.</p>', 'redux-framework-demo'),
                'fields' => array(


                    // Background Section
                    array(
                        'id' => 'wpjm-resume-section-archive-background',
                        'type' => 'section',
                        'title' => __('Backgrounds', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all backgrounds on the overall resume listings page.', 'redux-framework-demo'),
                        'indent' => true
                    ),

                    array(
                        'id' => 'wpjm-resume-search-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes', '.resume_filters .search_resumes'),
                        'title' => __('Resume Search Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for the main resume search area.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-search-input-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes input', '#wpjm-job-styles .resume_filters .search_resumes select', '.resume_filters .search_resumes input', '.resume_filters .search_resumes select'),
                        'title' => __('Resume Search Input Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for the main resume search area.', 'redux-framework-demo'),
                    ),

                     array(
                        'id' => 'wpjm-resume-filters-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .resume_filters .resume_types', '#wpjm-job-styles .resume_filters .showing_resumes', '.resume_filters .resume_types', '.resume_filters .showing_resumes'),
                        'title' => __('Filters Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for the job filter area (default: #F9F9F9).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-featured-listing-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.resumes li.resume.resume_featured a', '#wpjm-job-styles ul.resumes li.no_resume_listings_found.resume_featured a', 'ul.resumes li.resume.resume_featured a', 'ul.resumes li.no_resume_listings_found.resume_featured a'),
                        'title' => __('Featured Resume Listing Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for featured job listings (default: #FEFEE5).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-featured-listing-hover-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.resumes li.resume.resume_featured a:hover', '#wpjm-job-styles ul.resumes li.no_resume_listings_found.resume_featured a:hover', '#wpjm-job-styles ul.resumes li.resume.resume_featured a:focus', '#wpjm-job-styles ul.resumes li.no_resume_listings_found.resume_featured a:focus', 'ul.resumes li.resume.resume_featured a:hover', 'ul.resumes li.no_resume_listings_found.resume_featured a:hover', 'ul.resumes li.resume.resume_featured a:focus', 'ul.resumes li.no_resume_listings_found.resume_featured a:focus'),
                        'title' => __('Featured Resume Listing Hover Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color when hovering over a job listing (default: #FEFED8).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-normal-listing-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.resumes li.resume a', '#wpjm-job-styles ul.resumes li.no_resume_listings_found a', 'ul.resumes li.resume a', 'ul.resumes li.no_resume_listings_found a'),
                        'title' => __('Normal Resume Listing Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color for normal job listings (default: #FFFFFF).', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-normal-listing-hover-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles ul.resumes li.resume a:hover', '#wpjm-job-styles ul.resumes li.no_resume_listings_found a:hover', '#wpjm-job-styles ul.resumes li.resume a:focus', '#wpjm-job-styles ul.resumes li.no_resume_listings_found a:focus', 'ul.resumes li.resume a:hover', 'ul.resumes li.no_resume_listings_found a:hover', 'ul.resumes li.resume a:focus', 'ul.resumes li.no_resume_listings_found a:focus'),
                        'title' => __('Normal Resume Listing Hover Background', 'redux-framework-demo'),
                        'subtitle' => __('Pick a background color when hovering over a job listing (default: #FCFCFC).', 'redux-framework-demo'),
                    ),


                    // Border Section
                    array(
                        'id' => 'wpjm-resume-section-archive-borders',
                        'type' => 'section',
                        'title' => __('Borders', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all borders on the overall listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),
 
                    array(
                        'id' => 'wpjm-resume-search-section-border',
                        'type' => 'border',
                        'title' => __('Search Section Borders', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the main search section. Measured in px.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes', '.resume_filters .search_resumes'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,
                    ),

                    array(
                        'id' => 'wpjm-resume-search-input-section-border',
                        'type' => 'border',
                        'title' => __('Search Input Field Borders', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the main search section. Measured in px.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes input', '#wpjm-job-styles .resume_filters .search_resumes select', '.resume_filters .search_resumes input', '.resume_filters .search_resumes select'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,
                    ),

                    array(
                        'id' => 'wpjm-resume-listings-top-border',
                        'type' => 'border',
                        'title' => __('All Resume Listings Top Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the resume listings.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles div.resumes ul.resumes', 'div.resumes ul.resumes'),
                        'all'   => false,
                        'top' => true,
                        'right' => false,
                        'left'  => false,
                        'bottom' => false,
                    ),

                    array(
                        'id' => 'wpjm-resume-featured-listing-border',
                        'type' => 'border',
                        'title' => __('Featured Resume Listing Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the featured resume listings.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles ul.resumes li.resume.resume_featured', 'ul.resumes li.resume.resume_featured'),
                        'desc' => __('By default only the bottom border will be set to a width of 1px, with a color of #eee and set to solid. Settings here will affect all four sides of the resume listing.', 'redux-framework-demo'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,                        
                    ),

                    array(
                        'id' => 'wpjm-resume-normal-listing-border',
                        'type' => 'border',
                        'title' => __('Normal Resume Listing Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for the normal resume listings.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles ul.resumes li.resume', '#wpjm-job-styles ul.resumes li.no_resumes_found', 'ul.resumes li.resume', 'ul.resumes li.no_resumes_found'),
                        'desc' => __('By default only the bottom border will be set to a width of 1px, with a color of #eee and set to solid. Settings here will affect all four sides of the resume listing.', 'redux-framework-demo'),
                        'all'   => false,
                        'top' => true,
                        'right' => true,
                        'left'  => true,
                        'bottom' => true,
                    ),


                    // Fonts Section
                    array(
                        'id' => 'wpjm-resume-section-archive-fonts',
                        'type' => 'section',
                        'title' => __('Fonts', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all fonts on the overall resume listings page.', 'redux-framework-demo'),
                        'indent' => true
                    ),
                    array(
                        'id' => 'wpjm-resume-search-section-font',
                        'type' => 'typography',
                        'title' => __('Resume Search Fields', 'redux-framework-demo'),
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true,
                        'subsets'=>true,
                        'font-size'=>true,
                        'line-height'=>true,
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true,
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes input', '#wpjm-job-styles .resume_filters .search_resumes select', '#wpjm-job-styles .resume_filters .search_resumes input[placeholder]', '.resume_filters .search_resumes input', '.resume_filters .search_resumes select', '.resume_filters .search_resumes input[placeholder]'),
                        'units' => 'px',
                        'subtitle' => __('Applies to all search input fields in the main search bar.', 'redux-framework-demo'),
                    ),
                    array(
                        'id' => 'wpjm-resume-search-filters-font',
                        'type' => 'typography',
                        'title' => __('Resume Search Filters', 'redux-framework-demo'),
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true,
                        'font-size'=>true,
                        'line-height'=>true,
                        'color'=>true,
                        'preview'=>true,
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .resume_filters .showing_resumes', '#wpjm-job-styles .resume_filters .showing_resumes', '.showing_resumes_filters .showing_resumes li', '.resume_filters .showing_resumes'),
                        'units' => 'px', 
                        'subtitle' => __('Applies to all the resume search filters.', 'redux-framework-demo'),                        
                    ),
                    array(
                        'id' => 'wpjm-resume-all-listings-font',
                        'type' => 'typography',
                        'title' => __('Resume Listing Heading', 'redux-framework-demo'),
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                    
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles ul.resumes li.resume a div.candidate-column h3', '#wpjm-job-styles ul.resumes li.no_resumes_found a div.candidate-column h3', 'ul.resumes li.resume a div.candidate-column h3', 'ul.resumes li.no_resumes_found a div.candidate-column h3'),                       
                        'units' => 'px', 
                        'subtitle' => __('Applies to all resume headings.', 'redux-framework-demo'),                       
                    ),
                    array(
                        'id' => 'wpjm-resume-all-listings-meta-font',
                        'type' => 'typography',
                        'title' => __('Resume Listing Meta', 'redux-framework-demo'),                        
                        'google' => true,
                        'font-backup' => true,
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                        
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles ul.resumes li.resume a div.candidate-column', '#wpjm-job-styles ul.resumes li.resume a div.candidate-column .candidate-title strong', '#wpjm-job-styles ul.resumes li.resume a .resume-meta date', '#wpjm-job-styles ul.resumes li.resume a .resume-meta .resume-category', '#wpjm-job-styles ul.resumes li.resume a .resume-meta', '#wpjm-job-styles ul.resumes li.resume a div.candidate-location-column .candidate-location', 'ul.resumes li.resume a div.candidate-column', 'ul.resumes li.resume a div.candidate-column .candidate-title strong', 'ul.resumes li.resume a .resume-meta date', 'ul.resumes li.resume a .resume-meta .resume-category', 'ul.resumes li.resume a .resume-meta', 'ul.resumes li.resume a div.candidate-location-column .candidate-location'),    
                        'units' => 'px', 
                        'subtitle' => __('Applies to all resumes meta information.', 'redux-framework-demo'),
                    ),


                    // Padding Section
                    array(
                        'id' => 'wpjm-resume-section-archive-padding',
                        'type' => 'section',
                        'title' => __('Padding / Margin', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used on the overall resume listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-resume-search-section-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes', '.resume_filters .search_resumes'), 
                        'mode' => 'padding', 
                        'units' => 'em', 
                        'display_units' => false, 
                        'title' => __('Resume Search Section Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used for the main resume search section.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-search-section-input-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes input', '#wpjm-job-styles .resume_filters .search_resumes select', '.resume_filters .search_resumes input', '.resume_filters .search_resumes select'), 
                        'mode' => 'padding',   
                        'units' => 'em',                
                        'display_units' => false, 
                        'title' => __('Resume Search Section Input Fields Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used for input fields (e.g. Job Keywords) in the resume search section.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjmp-resume-listing-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles ul.resumes li.resume a', '#wpjm-job-styles ul.resumes li.no_resumes_found a', 'ul.resumes li.resume a', 'ul.resumes li.no_resumes_found a'), 
                        'mode' => 'padding',                        
                        'units' => 'em',                         
                        'display_units' => false, 
                        'title' => __('Resume Listing Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used for each listing in the overall resume listings view.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),


                    // Width Section
                    array(
                        'id' => 'wpjm-resume-section-dimensions',
                        'type' => 'section',
                        'title' => __('Dimensions', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used on the overall resume listings page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id'             => 'wpjm-resume-search-section-input-width',
                        'type'           => 'dimensions',
                        'units'    => array('em','px','%'),
                        'units_extended' => 'true', 
                        'output' => array('#wpjm-job-styles .resume_filters .search_resumes input', '#wpjm-job-styles .resume_filters .search_resumes select', '.resume_filters .search_resumes input', '.resume_filters .search_resumes select'), 
                        'title'          => __( 'Width / Height', 'redux-framework-demo' ),
                        'subtitle'       => __( 'Allow your users to choose width / height of the resume search input fields.', 'redux-framework-demo' ),
                        'default'        => array(
                            'width'  => 50,
                            'height' => 100,
                        ) 
                    ),
                ),
            );
            


            $this->sections[] = array(
                'icon' => 'el-icon-group-alt',
                'title' => __('Single Resume', 'redux-framework-demo'),
                'desc' => __('<p class="description">Styling options for the single resume listing view</p>', 'redux-framework-demo'),
                'fields' => array(

                    // Background Section
                    array(
                        'id' => 'wpjm-resume-section-single-background',
                        'type' => 'section',
                        'title' => __('Backgrounds', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all backgrounds on the single resumes listing view.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-resume-single-listing-company-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .single-resume .resume-aside', '.single-resume .resume-aside'),
                        'title' => __('Resume Description Background'),
                        'subtitle' => __('Pick a background color for resume meta information located below the title.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-single-listing-applybutton-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles .single-resume .resume_contact .resume_contact_button', '.single-resume .resume_contact .resume_contact_button'),
                        'title' => __('Resume Contact Button Background'),
                        'subtitle' => __('Pick a background color for resume contact button.', 'redux-framework-demo'),
                    ),



                    // Border Section
                    array(
                        'id' => 'wpjm-resume-section-single-borders',
                        'type' => 'section',
                        'title' => __('Borders', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all borders on a single resume page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),


                    array(
                        'id' => 'wpjm-resume-single-listing-company-border',
                        'type' => 'border',
                        'title' => __('Resume Description Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for resume description section.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .single-resume .resume-aside', '.single-resume .resume-aside'),
                    ),

                    array(
                        'id' => 'wpjm-resume-single-listing-applybutton-border',
                        'type' => 'border',
                        'title' => __('Resume Contact Button Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border options for resume contact button.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles .single-resume .resume_contact .resume_contact_button', '.single-resume .resume_contact .resume_contact_button'),                        
                    ),



                    // Fonts Section
                    array(
                        'id' => 'wpjm-resume-section-single-listing-fonts',
                        'type' => 'section',
                        'title' => __('Fonts', 'redux-framework-demo'),
                        'subtitle' => __('This section adds font options for a single resume page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                     array(
                        'id' => 'wpjm-resume-single-listing-heading-font',
                        'type' => 'typography',
                        'title' => __('Single Resume Listing Heading', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,         
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .single-resume h1.post-title', '.single-resume h1.post-title'),                         
                        'units' => 'px', 
                        'subtitle' => __('Applies to the main listing heading on the single resume page view.', 'redux-framework-demo'),                        
                    ),

                    array(
                        'id' => 'wpjm-resume-single-listing-company-heading-font',
                        'type' => 'typography',
                        'title' => __('Resume Description Heading', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                       
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .single-resume .resume-aside .job-title', '.single-resume .resume-aside .job-title'),                         
                        'units' => 'px', 
                        'subtitle' => __('Applies to the resume title in the resume description area.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-single-listing-applybutton-font',
                        'type' => 'typography',
                        'title' => __('Contact Button', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                       
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles .single-resume .resume_contact .resume_contact_button', '.single-resume .resume_contact .resume_contact_button'),                    
                        'units' => 'px', 
                        'subtitle' => __('Applies to the contact button in the single resume listing view.', 'redux-framework-demo'),
                    ),

                    
                    // Padding / Margin Section
                    array(
                        'id' => 'wpjm-resume-single-listing-padding',
                        'type' => 'section',
                        'title' => __('Padding / Margin', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used on the single resume page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-resume-single-listing-company-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles .single-resume .resume-aside', '.single-resume .resume-aside'), 
                        'mode' => 'padding',                        
                        'units' => 'em',                         
                        'display_units' => false, 
                        'title' => __('Resume Description Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used on the resume description section.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),                        
                    ),
                ),
            );



            $this->sections[] = array(
                'icon' => 'el-icon-inbox-alt',
                'title' => __('Submit Resume', 'redux-framework-demo'),
                'desc' => __('<p class="description">Styling options for submitting a job listing.</p>', 'redux-framework-demo'),
                'fields' => array(

                    // Background Section
                    array(
                        'id' => 'wpjm-resume-submit-listing-background',
                        'type' => 'section',
                        'title' => __('Backgrounds', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all backgrounds during the resume submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-button-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form .button', '#submit-resume-form.job-manager-form .button'),
                        'preview' => false,
                        'title' => __('Button Background'),
                        'subtitle' => __('Pick a background color for all buttons during the resume submission process.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-button-hover-background',
                        'type' => 'background',
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form .button:hover', '#submit-resume-form.job-manager-form .button:hover'),
                        'preview' => false,
                        'title' => __('Button Hover Background'),
                        'subtitle' => __('Pick a background color for all buttons during when hovered upon.', 'redux-framework-demo'),
                    ),

                    // Borders Section
                    array(
                        'id' => 'wpjm-resume-submit-listing-borders',
                        'type' => 'section',
                        'title' => __('Borders', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all borders during the resume submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-input-border',
                        'type' => 'border',
                        'title' => __('Input Borders', 'redux-framework-demo'),
                        'subtitle' => __('Set the border for the input / textarea elements during the resume submission process.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form fieldset input.input-text', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset textarea', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset select', '#submit-resume-form.job-manager-form fieldset input.input-text', '#submit-resume-form.job-manager-form fieldset textarea', '#submit-resume-form.job-manager-form fieldset select'),
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-fieldset-border',
                        'type' => 'border',
                        'title' => __('Fieldset Bottom Border', 'redux-framework-demo'),
                        'subtitle' => __('Set the border for areas between the input elements during the resume submission process.', 'redux-framework-demo'),
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form fieldset', '#submit-resume-form.job-manager-form fieldset'),
                        'all'   => false,
                        'top' => false,
                        'right' => false,
                        'left'  => false,
                        'bottom' => true,
                    ),


                    // Fonts Section
                    array(
                        'id' => 'wpjm-resume-submit-listing-fonts',
                        'type' => 'section',
                        'title' => __('Fonts', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all fonts during the resume submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-label-font',
                        'type' => 'typography',
                        'title' => __('Labels', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                                      
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form fieldset label', '#submit-resume-form.job-manager-form fieldset label'),                         
                        'units' => 'px', 
                        'subtitle' => __('Applies to all labels during the resume submission process.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-input-font',
                        'type' => 'typography',
                        'title' => __('Input Fields', 'redux-framework-demo'),                        
                        'google' => true, 
                        'font-backup' => true, 
                        'font-style'=>true, 
                        'subsets'=>true, 
                        'font-size'=>true,
                        'line-height'=>true,                        
                        'color'=>true,
                        'preview'=>true, 
                        'all_styles' => true, 
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form fieldset input.input-text', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset textarea', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset select', '#wpjm-job-styles #submit-resume-form.job-manager-form input[placeholder]', '#submit-resume-form.job-manager-form fieldset input.input-text', '#submit-resume-form.job-manager-form fieldset textarea', '#submit-resume-form.job-manager-form fieldset select'),    
                        'units' => 'px', 
                        'subtitle' => __('Applies to all input / textarea fields during the resume submission process.', 'redux-framework-demo'),
                    ),


                    // Padding Section
                    array(
                        'id' => 'wpjm-resume-submit-listing-padding',
                        'type' => 'section',
                        'title' => __('Padding / Margin', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used during the resume submission process.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-label-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form fieldset label', '#submit-resume-form.job-manager-form fieldset label'), 
                        'mode' => 'padding', 
                        'units' => 'em', 
                        'display_units' => false, 
                        'title' => __('Label Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used on all labels.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),

                    array(
                        'id' => 'wpjm-resume-submit-listing-input-padding',
                        'type' => 'spacing',
                        'output' => array('#wpjm-job-styles #submit-resume-form.job-manager-form fieldset input.input-text', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset textarea', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset select', '#submit-resume-form.job-manager-form fieldset input.input-text', '#submit-resume-form.job-manager-form fieldset textarea', '#submit-resume-form.job-manager-form fieldset select'), 
                        'mode' => 'padding', 
                        'all' => true, 
                        'units' => 'em',                         
                        'display_units' => false, 
                        'title' => __('Input Field Padding', 'redux-framework-demo'),
                        'subtitle' => __('Specifies the padding used on all input / textarea fields.', 'redux-framework-demo'),
                        'desc' => __('All units set to calculate in <em><strong>em</strong></em>.', 'redux-framework-demo'),
                    ),


                    // Width Section
                    array(
                        'id' => 'wpjm-resume-submit-input-dimensions',
                        'type' => 'section',
                        'title' => __('Dimensions', 'redux-framework-demo'),
                        'subtitle' => __('This section adds styles for all padding / margin used on resume submission page.', 'redux-framework-demo'),
                        'indent' => true 
                    ),

                    array(
                        'id'             => 'wpjm-resume-submit-section-input-width',
                        'type'           => 'dimensions',
                        'units'          => array('em','px','%'),
                        'units_extended' => 'true', 
                        'output'         => array('#wpjm-job-styles #submit-resume-form.job-manager-form fieldset input.input-text', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset textarea', '#wpjm-job-styles #submit-resume-form.job-manager-form fieldset select', '#submit-resume-form.job-manager-form fieldset input.input-text', '#submit-resume-form.job-manager-form fieldset textarea', '#submit-resume-form.job-manager-form fieldset select'), 
                        'title'          => __( 'Width / Height', 'redux-framework-demo' ),
                        'subtitle'       => __( 'Allow your users to choose width / height of the resume search input fields.', 'redux-framework-demo' ),
                        'default'        => array(
                            'width'  => 200,
                            'height' => 32,
                        )
                    ), 
                ),
            );
            };
        }

        public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
            $this->args['help_tabs'][] = array(
                'id' => 'redux-opts-1',
                'title' => __('Support', 'redux-framework-demo'),
                'content' => __('<p>Please note that this plugin has been developed to work with the latest version of WP Job Manager and has not been tested on earlier editions. In the event that you require further support, please contact us directly at <a href="mailto:riaan@tinygiantstudios.co.za">riaan@tinygiantstudios.co.za</a>.</p>', 'redux-framework-demo')
            );

            // Set the help sidebar
            $this->args['help_sidebar'] = __('<p><a style="display: block; text-align: center;" id="redux_save" class="button button-primary" href="mailto:riaan@tinygiantstudios.co.za">Contact Support</a></p>', 'redux-framework-demo');
        }

        /*
         * 
            All the possible arguments for Redux.
            For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
         * 
         */
        public function setArguments() {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.

            $this->args = array(
                // TYPICAL -> Change these values as you need/desire
                'opt_name' => 'redux_demo', // This is where your data is stored in the database and also becomes your global variable name.
                'display_name' => 'WP Job Manager - Job Board Designer', // Name that appears at the top of your panel
                'display_version' => '1.1', // Version that appears at the top of your panel
                'menu_type' => 'menu', //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu' => true, // Show the sections below the admin menu item or not
                'menu_title' => __('Job Designer', 'redux-framework-demo'),
                'page' => __('Job Board Designer', 'redux-framework-demo'),
                'google_api_key' => 'AIzaSyDFR99UaB0zb_zauMKo27xpitQTpbzOY-4', // Must be defined to add google fonts to the typography module
                'global_variable' => '', // Set a different name for your global variable other than the opt_name
                'dev_mode' => false, // Show the time the page took to load, etc
                'customizer' => true, // Enable basic customizer support
                
                // OPTIONAL -> Give you extra features
                'page_priority' => null, // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent' => 'themes.php', // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions' => 'manage_options', // Permissions needed to access the options panel.
                'menu_icon' => '', // Specify a custom URL to an icon
                'last_tab' => '0_section_group_li', // Force your panel to always open to a specific tab (by id)
                'page_icon' => '', // Icon displayed in the admin panel next to your menu_title
                'page_slug' => '_options', // Page slug used to denote the panel
                'save_defaults' => true, // On load save the defaults to DB before user clicks save or not
                'default_show' => false, // If true, shows the default value next to each field that is not the default value.
                'default_mark' => '', // What to print by the field's title if the value shown is default. Suggested: *
                
                // CAREFUL -> These options are for advanced use only
                'transient_time' => 60 * MINUTE_IN_SECONDS,
                'output' => true, // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag' => true, // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                //'domain'              => 'redux-framework', // Translation domain key. Don't change this unless you want to retranslate all of Redux.
                'footer_credit'         => 'WP Job Manager - Job Styles | Developed by <a href="http://tinygiantstudios.co.za">Tiny Giant Studios</a>.', // Disable the footer credit of Redux. Please leave if you can help it.
                
                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database' => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'show_import_export' => true, // REMOVE
                'system_info' => false, // REMOVE
                'help_tabs' => array(),
                'help_sidebar' => '', // __( '', $this->args['domain'] );            
            );


            // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.     
            $this->args['share_icons'][] = array(
                'url' => 'https://www.facebook.com/tinygiantstudios',
                'title' => 'Like us on Facebook',
                'icon' => 'el-icon-facebook'
            );
            $this->args['share_icons'][] = array(
                'url' => 'https://twitter.com/tinygiantstudio',
                'title' => 'Follow us on Twitter',
                'icon' => 'el-icon-twitter'
            );

        }

    }

    new Redux_Framework_sample_config();
}
