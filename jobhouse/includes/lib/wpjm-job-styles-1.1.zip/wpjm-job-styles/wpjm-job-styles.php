<?php
/*
Plugin Name: WP Job Manager - Job Styles
Version: 1.1
Plugin URI: http://tinygiantstudios.co.za/store/wp-job-manager-job-styles
Author: Tiny Giant Studios
Author URI: http://www.tinygiantstudios.co.za
Description: Adds the ability to define custom styles for your WP Job Manager plugin.
*/


/*
 * Load Redux Framework
 */
if ( !class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/ReduxFramework/ReduxCore/framework.php' ) ) {
    require_once( dirname( __FILE__ ) . '/ReduxFramework/ReduxCore/framework.php' );
}

require_once( dirname( __FILE__ ) . '/wpjm-job-styles-config.php' );


/*
 * Load plugin js
 */
function wpjm_jquery() {
	if (!(wp_script_is( 'jquery', 'enqueued' ))) {
		// jQuery is NOT enqueued, let's load it from Google
		wp_register_script( 'jquery', '//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js', '', '1.10.2');
		wp_enqueue_script( 'jquery' );
	}

	wp_register_script('wpjm_scripts', plugins_url('/includes/js/wpjm-job-styles.js', __FILE__), array('jquery'));
	wp_enqueue_script( 'wpjm_scripts' );
}

add_action( 'wp_enqueue_scripts', 'wpjm_jquery' );

?>