jQuery(document).ready(function($) {
    $('html').attr('id','wpjm-job-styles'); 
});